#!/usr/bin/env python3
"""
Simula o Hadoop Streaming na própria máquina, sem Hadoop instalado: map -> shuffle and sort -> reduce.

Serve para testar os 4 scripts (mapper/reducer) antes de rodar no cluster, e para mostrar o fluxo do MapReduce.
Faz o mesmo que o Hadoop faz:
  1. MAP: cada arquivo de entrada passa por um mapper (com a variável mapreduce_map_input_file definida);
  2. SHUFFLE AND SORT: as linhas de todos os mappers são ordenadas pela chave (campo antes do primeiro TAB);
  3. REDUCE: o reducer lê as linhas já agrupadas por chave.

Uso:  python3 simular_streaming.py --entrada dados_trusted --saida mr_local [--lotes 1,2]
"""
import argparse
import os
import re
import subprocess
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))


def rodar(script, entrada_texto, env_extra=None):
    env = dict(os.environ, **(env_extra or {}))
    r = subprocess.run([sys.executable, os.path.join(AQUI, script)], input=entrada_texto, capture_output=True,
                       text=True, env=env, check=True)
    return r.stdout, r.stderr


def embaralhar_e_ordenar(texto):
    linhas = [l for l in texto.splitlines() if l]
    return "\n".join(sorted(linhas, key=lambda l: l.split("\t", 1)[0].encode("utf-8"))) + "\n"   # sort estável por chave


def job(mapper, reducer, arquivos, nome):
    saida_map, invalidas = [], 0
    for caminho in arquivos:
        with open(caminho, encoding="utf-8") as f:
            out, err = rodar(mapper, f.read(), {"mapreduce_map_input_file": os.path.abspath(caminho)})
        saida_map.append(out)
        invalidas += err.count("linhas_invalidas")
    mapeado = "".join(saida_map)
    ordenado = embaralhar_e_ordenar(mapeado)
    reduzido, _ = rodar(reducer, ordenado)
    print(f"[{nome}] map: {len(arquivos)} arquivo(s), {mapeado.count(chr(10))} linhas | "
          f"reduce: {len(set(l.split(chr(9), 1)[0] for l in ordenado.splitlines()))} chaves -> {reduzido.count(chr(10))} linhas"
          f" | linhas inválidas: {invalidas}")
    return reduzido


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--entrada", default="dados_trusted", help="pasta com trusted_produtos_N.csv e trusted_compras_N.csv")
    p.add_argument("--saida", default="mr_local", help="pasta dos resultados")
    p.add_argument("--lotes", help="lista de lotes separados por vírgula (padrão: todos)")
    a = p.parse_args()

    achados = {}
    for n in os.listdir(a.entrada):
        m = re.fullmatch(r"trusted_(produtos|compras)_(\d+)\.csv", n)
        if m:
            achados.setdefault(int(m.group(2)), set()).add(m.group(1))
    lotes = [n for n, t in sorted(achados.items()) if t == {"produtos", "compras"}]
    if a.lotes:
        lotes = [n for n in lotes if n in {int(x) for x in a.lotes.split(",")}]
    if not lotes:
        sys.exit(f"Nenhum lote completo (produtos + compras) em {a.entrada}")
    arquivos = [os.path.join(a.entrada, f"trusted_{t}_{n}.csv") for n in lotes for t in ("produtos", "compras")]

    os.makedirs(a.saida, exist_ok=True)
    por_produto = job("mapper_join.py", "reducer_join.py", arquivos, "job 1: junção")
    with open(os.path.join(a.saida, "mr_receita_por_produto.tsv"), "w", encoding="utf-8") as f:
        f.write(por_produto)
    # o job 2 lê a saída do job 1 (no Hadoop, ela fica no HDFS); aqui entra como um arquivo só
    tmp = os.path.join(a.saida, "_job1.tsv")
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(por_produto)
    por_categoria = job("mapper_soma.py", "reducer_soma.py", [tmp], "job 2: soma por categoria")
    os.remove(tmp)
    destino = os.path.join(a.saida, "mr_receita_por_categoria.tsv")
    with open(destino, "w", encoding="utf-8") as f:
        f.write("categoria\treceita_liquida\tcompras\tcanceladas\tpct_cancelamento\n" + por_categoria)
    print(f"\nResultado: {destino}\n")
    print(open(destino, encoding="utf-8").read())


if __name__ == "__main__":
    main()
