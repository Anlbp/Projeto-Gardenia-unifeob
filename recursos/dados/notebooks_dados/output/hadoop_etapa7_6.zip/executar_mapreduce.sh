#!/usr/bin/env bash
# MapReduce no cluster (Hadoop Streaming, executado pelo YARN). NÃO foi executado no desenvolvimento deste projeto;
# a lógica dos 4 scripts Python foi testada com simular_streaming.py.
#
# Pré-requisito: bash hdfs_carga.sh (os trusted precisam estar no HDFS).
# Uso:  bash executar_mapreduce.sh
set -euo pipefail

RAIZ=/gardenia
STREAMING_JAR=$(ls "$HADOOP_HOME"/share/hadoop/tools/lib/hadoop-streaming-*.jar | head -1)

hdfs dfs -rm -r -f "$RAIZ/mr/receita_por_produto" "$RAIZ/mr/receita_por_categoria"

# Job 1: junção compras x produtos. Lê as duas pastas; o mapper identifica a tabela pelo nome do arquivo.
hadoop jar "$STREAMING_JAR" \
  -D mapreduce.job.name=gardenia-join-compras-produtos \
  -D mapreduce.job.reduces=2 \
  -files mapper_join.py,reducer_join.py \
  -mapper "python3 mapper_join.py" \
  -reducer "python3 reducer_join.py" \
  -input "$RAIZ/trusted/produtos" -input "$RAIZ/trusted/compras" \
  -output "$RAIZ/mr/receita_por_produto"

# Job 2: soma por categoria (reducer único, o resultado é pequeno)
hadoop jar "$STREAMING_JAR" \
  -D mapreduce.job.name=gardenia-soma-por-categoria \
  -D mapreduce.job.reduces=1 \
  -files mapper_soma.py,reducer_soma.py \
  -mapper "python3 mapper_soma.py" \
  -reducer "python3 reducer_soma.py" \
  -input "$RAIZ/mr/receita_por_produto" \
  -output "$RAIZ/mr/receita_por_categoria"

hdfs dfs -cat "$RAIZ/mr/receita_por_categoria/part-*"
# acompanhar os jobs no YARN:  yarn application -list -appStates ALL
