#!/usr/bin/env bash
# YARN | rodar o job Spark da VM 3 sob o gerenciamento do YARN e inspecionar a fila de aplicações.
# NÃO foi executado no desenvolvimento deste projeto (precisa de Hadoop/YARN instalado).
#
# Limite do código atual: pipeline_vm3.py lê os CSVs de uma pasta LOCAL. Isso funciona em máquina única
# (pseudo-distribuído), onde os executores do YARN rodam na mesma máquina. Em cluster com vários nós, os dados teriam
# de ser lidos do HDFS (hdfs://...), o que exige trocar a leitura em lotes_trusted/ler_tabela.
set -euo pipefail

export HADOOP_CONF_DIR=${HADOOP_CONF_DIR:-$HADOOP_HOME/etc/hadoop}    # o Spark descobre o ResourceManager por aqui

# 1) o mesmo script da VM 3, trocando só o master (local[*] -> yarn)
python3 pipeline_vm3.py processar --master yarn --forcar --memoria 2g

# 2) equivalente com spark-submit, escolhendo recursos de cada executor
# spark-submit --master yarn --deploy-mode client --num-executors 2 --executor-memory 1g --executor-cores 1 pipeline_vm3.py processar --master yarn

# 3) acompanhamento
yarn node -list                      # nós do cluster e recursos
yarn application -list -appStates ALL
# yarn application -status <application_id>
# yarn logs -applicationId <application_id>
# yarn application -kill <application_id>
