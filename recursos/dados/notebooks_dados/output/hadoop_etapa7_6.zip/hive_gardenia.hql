-- Hive | tabelas externas sobre os CSVs do HDFS e as mesmas consultas do notebook 7.5 (Spark SQL), agora em HiveQL.
-- NÃO foi executado no desenvolvimento deste projeto (precisa de Hive instalado). Uso:  hive -f hive_gardenia.hql
--
-- EXTERNAL: o Hive guarda só os metadados; os arquivos continuam no HDFS (DROP TABLE não apaga os dados).
-- OpenCSVSerde lê tudo como STRING, por isso as views fazem o CAST.

CREATE DATABASE IF NOT EXISTS gardenia;
USE gardenia;

CREATE EXTERNAL TABLE IF NOT EXISTS clientes (
  id STRING, nome STRING, email STRING, idade STRING, telefone STRING, cpf STRING,
  data_nascimento STRING, data_cadastro STRING, cadastro_incompleto STRING)
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
WITH SERDEPROPERTIES ("separatorChar" = ",", "quoteChar" = "\"")
STORED AS TEXTFILE LOCATION '/gardenia/trusted/clientes'
TBLPROPERTIES ("skip.header.line.count" = "1");

CREATE EXTERNAL TABLE IF NOT EXISTS produtos (
  id STRING, nome STRING, categoria STRING, preco STRING, estoque STRING, peso STRING,
  satisfacao_media STRING, data_cadastro STRING)
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
WITH SERDEPROPERTIES ("separatorChar" = ",", "quoteChar" = "\"")
STORED AS TEXTFILE LOCATION '/gardenia/trusted/produtos'
TBLPROPERTIES ("skip.header.line.count" = "1");

CREATE EXTERNAL TABLE IF NOT EXISTS compras (
  id STRING, cliente_id STRING, produto_id STRING, quantidade STRING, valor_total STRING, desconto STRING,
  data_compra STRING, status STRING, satisfacao STRING)
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
WITH SERDEPROPERTIES ("separatorChar" = ",", "quoteChar" = "\"")
STORED AS TEXTFILE LOCATION '/gardenia/trusted/compras'
TBLPROPERTIES ("skip.header.line.count" = "1");

-- O número do lote está no nome do arquivo (trusted_compras_2.csv): INPUT__FILE__NAME é a coluna virtual do Hive.
-- Os ids reiniciam a cada lote, então a chave de junção é (lote, id), como no DW e no Spark.
CREATE VIEW IF NOT EXISTS vw_produtos AS
SELECT regexp_extract(INPUT__FILE__NAME, '_([0-9]+)[.]csv$', 1) AS lote,
       CAST(id AS INT) AS produto_id, nome AS produto, categoria, CAST(preco AS DOUBLE) AS preco
FROM produtos;

-- clientes sem os dados pessoais (nome, e-mail, telefone, CPF): é a view que as análises devem usar (LGPD)
CREATE VIEW IF NOT EXISTS vw_clientes AS
SELECT regexp_extract(INPUT__FILE__NAME, '_([0-9]+)[.]csv$', 1) AS lote,
       CAST(id AS INT) AS cliente_id, CAST(idade AS INT) AS idade,
       CASE WHEN idade IS NULL OR idade = '' THEN 'sem idade'
            WHEN CAST(idade AS INT) < 25 THEN '18-24' WHEN CAST(idade AS INT) < 35 THEN '25-34'
            WHEN CAST(idade AS INT) < 45 THEN '35-44' WHEN CAST(idade AS INT) < 55 THEN '45-54'
            WHEN CAST(idade AS INT) < 65 THEN '55-64' ELSE '65+' END AS faixa_etaria
FROM clientes;

CREATE VIEW IF NOT EXISTS vw_compras AS
SELECT regexp_extract(INPUT__FILE__NAME, '_([0-9]+)[.]csv$', 1) AS lote,
       CAST(id AS INT) AS compra_id, CAST(cliente_id AS INT) AS cliente_id, CAST(produto_id AS INT) AS produto_id,
       CAST(quantidade AS INT) AS quantidade, CAST(valor_total AS DOUBLE) AS valor_total, CAST(desconto AS DOUBLE) AS desconto,
       CAST(data_compra AS TIMESTAMP) AS data_compra, status, CAST(satisfacao AS INT) AS satisfacao
FROM compras;

CREATE VIEW IF NOT EXISTS fato_vendas AS
SELECT c.lote, c.compra_id, c.cliente_id, c.produto_id, p.produto, p.categoria, cl.faixa_etaria,
       c.valor_total AS valor_liquido,   -- desconto é percentual; valor_total já é o valor líquido (cancelado = 0)
       date_format(c.data_compra, 'yyyy-MM') AS mes,
       concat(year(c.data_compra), '-T', quarter(c.data_compra)) AS trimestre,
       c.status, (c.status <> 'cancelado') AS valida, c.satisfacao
FROM vw_compras c
JOIN vw_produtos p  ON c.lote = p.lote  AND c.produto_id = p.produto_id
JOIN vw_clientes cl ON c.lote = cl.lote AND c.cliente_id = cl.cliente_id;

-- ---------------------------------------------------------------- consultas (as mesmas do notebook 7.5)
-- 1) receita por trimestre e categoria, com a participação no trimestre (função de janela)
SELECT trimestre, categoria, ROUND(SUM(valor_liquido), 2) AS receita_liquida,
       ROUND(100 * SUM(valor_liquido) / SUM(SUM(valor_liquido)) OVER (PARTITION BY trimestre), 1) AS pct_do_trimestre
FROM fato_vendas WHERE valida
GROUP BY trimestre, categoria
ORDER BY trimestre, receita_liquida DESC;

-- 2) receita mensal e variação sobre o mês anterior (LAG)
SELECT mes, ROUND(receita, 2) AS receita_liquida,
       ROUND(100 * (receita - LAG(receita) OVER (ORDER BY mes)) / LAG(receita) OVER (ORDER BY mes), 1) AS variacao_pct
FROM (SELECT mes, SUM(valor_liquido) AS receita FROM fato_vendas WHERE valida GROUP BY mes) m
ORDER BY mes;

-- 3) os 3 produtos de maior receita em cada categoria
SELECT * FROM (
  SELECT categoria, lote, produto_id, produto, ROUND(SUM(valor_liquido), 2) AS receita_liquida,
         ROW_NUMBER() OVER (PARTITION BY categoria ORDER BY SUM(valor_liquido) DESC) AS posicao
  FROM fato_vendas WHERE valida
  GROUP BY categoria, lote, produto_id, produto) t
WHERE posicao <= 3
ORDER BY categoria, posicao;

-- 4) cancelamento por faixa etária
SELECT faixa_etaria, COUNT(*) AS compras, SUM(CASE WHEN valida THEN 0 ELSE 1 END) AS canceladas,
       ROUND(100 * AVG(CASE WHEN valida THEN 0.0 ELSE 1.0 END), 1) AS pct_cancelamento
FROM fato_vendas
GROUP BY faixa_etaria
HAVING COUNT(*) >= 100
ORDER BY pct_cancelamento DESC;
