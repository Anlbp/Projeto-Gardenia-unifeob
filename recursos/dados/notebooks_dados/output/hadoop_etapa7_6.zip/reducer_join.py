#!/usr/bin/env python3
"""
MapReduce (Hadoop Streaming) | Job 1, fase REDUCE: para cada produto, soma as compras e anexa a categoria.

Entrada: linhas do mapper_join.py, ordenadas pela chave (o Hadoop faz essa ordenação, a fase "shuffle and sort").
Saída (TAB): categoria, receita_liquida_em_centavos (não canceladas), compras_nao_canceladas, compras_canceladas
"""
import sys
from itertools import groupby


def principal():
    linhas = (l.rstrip("\n").split("\t") for l in sys.stdin if l.strip())
    for chave, grupo in groupby(linhas, key=lambda campos: campos[0]):
        categoria, receita, validas, canceladas = None, 0, 0, 0
        for campos in grupo:
            if campos[1] == "P":
                categoria = campos[2]
            elif campos[2] == "cancelado":
                canceladas += 1
            else:
                receita += int(campos[3])
                validas += 1
        if validas + canceladas == 0:
            continue                              # produto sem compras
        print(f"{categoria or 'sem_produto'}\t{receita}\t{validas}\t{canceladas}")


if __name__ == "__main__":
    principal()
