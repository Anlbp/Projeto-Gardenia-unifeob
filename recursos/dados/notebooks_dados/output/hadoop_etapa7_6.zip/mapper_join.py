#!/usr/bin/env python3
"""
MapReduce (Hadoop Streaming) | Job 1, fase MAP: junção de compras com produtos (reduce-side join).

Lê linhas CSV de trusted_produtos_N.csv e trusted_compras_N.csv. Como os dois arquivos entram no mesmo job, o mapper descobre
de qual tabela veio a linha pelo NOME DO ARQUIVO (o Hadoop informa em mapreduce_map_input_file) e marca o valor com P ou C.

Saída (separador TAB), com a chave "lote:produto_id":
    <lote>:<produto_id> TAB P TAB <categoria>
    <lote>:<produto_id> TAB C TAB <status> TAB <valor_liquido_em_centavos>
O reducer recebe todas as linhas de um produto juntas e junta categoria + compras.
"""
import csv
import os
import re
import sys


def contador(nome):
    # protocolo do Hadoop Streaming: aparece na tela do job, em "Counters"
    sys.stderr.write(f"reporter:counter:gardenia,{nome},1\n")


def centavos(texto):
    return int(round(float(texto) * 100))


def main():
    arquivo = os.environ.get("mapreduce_map_input_file") or os.environ.get("map_input_file") or ""
    m = re.search(r"trusted_(produtos|compras)_(\d+)\.csv", os.path.basename(arquivo))
    if not m:
        return                                   # arquivo que não faz parte do job
    tabela, lote = m.group(1), m.group(2)

    for linha in csv.reader(sys.stdin):
        if not linha or linha[0] == "id":        # cabeçalho (só existe no primeiro bloco do arquivo)
            continue
        try:
            if tabela == "produtos":             # id,nome,categoria,preco,...
                print(f"{lote}:{int(linha[0])}\tP\t{linha[2] or 'Não informada'}")   # categoria anulada na limpeza
            else:                                # id,cliente_id,produto_id,quantidade,valor_total,desconto,data_compra,status,satisfacao
                liquido = centavos(linha[4])             # desconto é percentual; valor_total já é o valor líquido (cancelado = 0)
                print(f"{lote}:{int(linha[2])}\tC\t{linha[7]}\t{liquido}")
        except (ValueError, IndexError):
            contador("linhas_invalidas")


if __name__ == "__main__":
    main()
