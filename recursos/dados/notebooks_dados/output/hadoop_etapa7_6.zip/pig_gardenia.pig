-- Pig | o mesmo cálculo do MapReduce (receita líquida por categoria), escrito como fluxo de dados em Pig Latin.
-- NÃO foi executado no desenvolvimento deste projeto (precisa de Pig e do piggybank instalados).
--
-- Uso:  pig -param LOTE=1 pig_gardenia.pig
-- Cada comando vira um ou mais jobs MapReduce; o Pig monta o plano, no lugar de escrevermos mapper e reducer.
%default LOTE '1'
%default RAIZ '/gardenia'

REGISTER /usr/lib/pig/piggybank.jar;     -- o caminho do piggybank muda conforme a instalação
-- CSVExcelStorage entende campos entre aspas e ignora o cabeçalho
DEFINE CSV org.apache.pig.piggybank.storage.CSVExcelStorage(',', 'NO_MULTILINE', 'UNIX', 'SKIP_INPUT_HEADER');

produtos = LOAD '$RAIZ/trusted/produtos/trusted_produtos_$LOTE.csv' USING CSV
           AS (id:int, nome:chararray, categoria:chararray, preco:double, estoque:int, peso:double,
               satisfacao_media:double, data_cadastro:chararray);
compras  = LOAD '$RAIZ/trusted/compras/trusted_compras_$LOTE.csv' USING CSV
           AS (id:int, cliente_id:int, produto_id:int, quantidade:int, valor_total:double, desconto:double,
               data_compra:chararray, status:chararray, satisfacao:int);

-- 1) receita líquida por categoria (compras não canceladas)
validas = FILTER compras BY status != 'cancelado';
juncao  = JOIN validas BY produto_id, produtos BY id;
base    = FOREACH juncao GENERATE produtos::categoria AS categoria,
                                  validas::valor_total AS valor_liquido;   -- desconto é percentual; valor_total já é líquido
por_cat = GROUP base BY categoria;
receita = FOREACH por_cat GENERATE group AS categoria, COUNT(base) AS compras,
                                   ROUND_TO(SUM(base.valor_liquido), 2) AS receita_liquida;
receita_ord = ORDER receita BY receita_liquida DESC;
STORE receita_ord INTO '$RAIZ/pig/receita_por_categoria_$LOTE' USING PigStorage(',');

-- 2) compras por status
por_status = GROUP compras BY status;
contagem   = FOREACH por_status GENERATE group AS status, COUNT(compras) AS compras;
STORE contagem INTO '$RAIZ/pig/compras_por_status_$LOTE' USING PigStorage(',');
