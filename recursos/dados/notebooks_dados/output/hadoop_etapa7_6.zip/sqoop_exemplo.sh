#!/usr/bin/env bash
# Sqoop | transferência entre banco relacional e HDFS.
# EXEMPLO, NÃO executável neste projeto: aqui não existe banco relacional de origem (a fonte são arquivos CSV
# do simulador, copiados por SCP). O Sqoop passaria a fazer sentido se as compras ficassem num MySQL/PostgreSQL.
# Atenção: o Apache Sqoop foi desativado pela Apache; o equivalente atual é o Spark lendo por JDBC (spark.read.jdbc).
set -euo pipefail

JDBC="jdbc:mysql://IP_DO_BANCO:3306/gardenia"      # banco hipotético
USUARIO=gardenia_leitura                            # senha: use --password-file, nunca a senha na linha de comando

# importar a tabela compras para a zona raw do HDFS (4 mappers lendo faixas de id em paralelo)
sqoop import --connect "$JDBC" --username "$USUARIO" --password-file /user/gardenia/.senha \
  --table compras --split-by id --num-mappers 4 \
  --target-dir /gardenia/raw/compras --as-textfile --fields-terminated-by ','

# importação incremental: só o que chegou depois da última carga
sqoop import --connect "$JDBC" --username "$USUARIO" --password-file /user/gardenia/.senha \
  --table compras --target-dir /gardenia/raw/compras \
  --incremental append --check-column id --last-value 5000

# o caminho inverso: devolver um resultado do HDFS para uma tabela do banco (por exemplo, os segmentos de clientes)
sqoop export --connect "$JDBC" --username "$USUARIO" --password-file /user/gardenia/.senha \
  --table segmentos_clientes --export-dir /gardenia/ml/segmentos --input-fields-terminated-by ','
