#!/usr/bin/env python3
"""MapReduce (Hadoop Streaming) | Job 2, fase MAP: repassa as linhas (a chave é a categoria, o primeiro campo)."""
import sys

for linha in sys.stdin:
    if linha.strip():
        sys.stdout.write(linha)
