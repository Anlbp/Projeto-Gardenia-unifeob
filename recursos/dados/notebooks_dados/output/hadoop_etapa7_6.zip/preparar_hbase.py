#!/usr/bin/env python3
"""
HBase | prepara o arquivo TSV das compras com a chave de linha (row key) pensada para consulta por cliente.

Chave:  <lote 2 dígitos>#<cliente_id 7 dígitos>#<data_compra AAAAMMDDhhmmss>#<compra_id 7 dígitos>
Por quê: o HBase guarda as linhas ordenadas pela chave. Com o cliente no início, todas as compras de um cliente ficam
         juntas e saem de uma só leitura por prefixo (scan), em ordem de data. Os dígitos fixos (zeros à esquerda) mantêm
         a ordem correta ("0000042" vem antes de "0000100"; sem os zeros, "100" viria antes de "42").

Uso:  python3 preparar_hbase.py --entrada dados_trusted --saida hbase_compras.tsv
Colunas do TSV (família "d"):  d:produto_id d:quantidade d:valor_liquido d:status d:satisfacao
"""
import argparse
import csv
import os
import re
import sys
from datetime import datetime


def centavos(texto):
    return int(round(float(texto) * 100))


def linhas_compras(pasta):
    for nome in sorted(os.listdir(pasta)):
        m = re.fullmatch(r"trusted_compras_(\d+)\.csv", nome)
        if not m:
            continue
        lote = int(m.group(1))
        with open(os.path.join(pasta, nome), encoding="utf-8", newline="") as f:
            for r in csv.DictReader(f):
                data = datetime.fromisoformat(r["data_compra"])
                chave = f"{lote:02d}#{int(r['cliente_id']):07d}#{data:%Y%m%d%H%M%S}#{int(r['id']):07d}"
                liquido = centavos(r["valor_total"]) / 100   # desconto é percentual; valor_total já é líquido
                yield [chave, r["produto_id"], r["quantidade"], f"{liquido:.2f}", r["status"], r["satisfacao"]]


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--entrada", default="dados_trusted")
    p.add_argument("--saida", default="hbase_compras.tsv")
    a = p.parse_args()
    n = 0
    with open(a.saida, "w", encoding="utf-8", newline="") as f:
        for linha in linhas_compras(a.entrada):
            f.write("\t".join(linha) + "\n")
            n += 1
    if n == 0:
        sys.exit(f"Nenhum trusted_compras_N.csv em {a.entrada}")
    print(f"{n} linhas gravadas em {a.saida}")


if __name__ == "__main__":
    main()
