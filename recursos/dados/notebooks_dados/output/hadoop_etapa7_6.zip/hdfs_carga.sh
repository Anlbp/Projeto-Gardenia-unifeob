#!/usr/bin/env bash
# HDFS | organiza as zonas do projeto no HDFS e carrega os CSVs.
# Requer Hadoop instalado e o HDFS no ar (start-dfs.sh). NÃO foi executado no desenvolvimento deste projeto.
#
# Uso:  bash hdfs_carga.sh [pasta_trusted_local] [pasta_raw_local] [pasta_quarentena_local]
#   padrão: dados_trusted   (na VM 3, só chegam os trusted; raw e quarentena ficam na VM 2)
set -euo pipefail

RAIZ=/gardenia
TRUSTED_LOCAL=${1:-dados_trusted}
RAW_LOCAL=${2:-}
QUAR_LOCAL=${3:-}

# 1) uma pasta por zona e por tabela (cada tabela em pasta própria, porque o Hive e o MapReduce leem pastas)
for zona in raw trusted quarentena; do
  for tabela in clientes produtos compras; do
    hdfs dfs -mkdir -p "$RAIZ/$zona/$tabela"
  done
done
hdfs dfs -mkdir -p "$RAIZ/mr" "$RAIZ/pig" "$RAIZ/hbase" "$RAIZ/warehouse"

# 2) carga: -put -f substitui o arquivo se ele já existir (reprocessamento de um lote)
for tabela in clientes produtos compras; do
  hdfs dfs -put -f "$TRUSTED_LOCAL"/trusted_${tabela}_*.csv "$RAIZ/trusted/$tabela/"
  [ -n "$RAW_LOCAL" ]  && hdfs dfs -put -f "$RAW_LOCAL"/${tabela}_*.csv "$RAIZ/raw/$tabela/" || true
  [ -n "$QUAR_LOCAL" ] && ls "$QUAR_LOCAL"/quarentena_${tabela}_*.csv >/dev/null 2>&1 \
                       && hdfs dfs -put -f "$QUAR_LOCAL"/quarentena_${tabela}_*.csv "$RAIZ/quarentena/$tabela/" || true
done

# 3) replicação: o padrão é 3 cópias de cada bloco. Em máquina única (pseudo-distribuído) só existe 1 DataNode: usar 1.
hdfs dfs -setrep -w 1 "$RAIZ" || true

# 4) conferência
hdfs dfs -ls -R "$RAIZ/trusted"
hdfs dfs -du -h "$RAIZ"
hdfs fsck "$RAIZ/trusted" -files -blocks | tail -15
