#!/usr/bin/env python3
"""
MapReduce (Hadoop Streaming) | Job 2, fase REDUCE: soma os produtos de cada categoria.

Saída (TAB): categoria, receita_liquida (R$), compras_nao_canceladas, compras_canceladas, pct_cancelamento
"""
import sys
from itertools import groupby


def principal():
    linhas = (l.rstrip("\n").split("\t") for l in sys.stdin if l.strip())
    for categoria, grupo in groupby(linhas, key=lambda campos: campos[0]):
        receita = validas = canceladas = 0
        for _, r, v, c in grupo:
            receita += int(r); validas += int(v); canceladas += int(c)
        pct = 100 * canceladas / (validas + canceladas)
        print(f"{categoria}\t{receita / 100:.2f}\t{validas}\t{canceladas}\t{pct:.1f}")


if __name__ == "__main__":
    principal()
