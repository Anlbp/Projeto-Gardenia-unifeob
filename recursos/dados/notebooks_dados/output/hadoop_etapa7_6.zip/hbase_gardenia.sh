#!/usr/bin/env bash
# HBase | tabela de compras com acesso rápido ao histórico de um cliente.
# NÃO foi executado no desenvolvimento deste projeto (precisa de HBase instalado). O preparar_hbase.py foi testado.
#
# Quando o HBase faz sentido aqui: "mostre as últimas compras do cliente X" (leitura pontual, em milissegundos).
# Quando NÃO faz: somar a receita do ano (agregação sobre tudo). Isso é trabalho para Spark/Hive.
set -euo pipefail

python3 preparar_hbase.py --entrada dados_trusted --saida hbase_compras.tsv
hdfs dfs -mkdir -p /gardenia/hbase
hdfs dfs -put -f hbase_compras.tsv /gardenia/hbase/compras.tsv

hbase shell <<'SHELL'
create_namespace 'gardenia'
create 'gardenia:compras', {NAME => 'd', VERSIONS => 1}
SHELL

# carga em massa a partir do TSV (é um job MapReduce)
hbase org.apache.hadoop.hbase.mapreduce.ImportTsv \
  -Dimporttsv.columns=HBASE_ROW_KEY,d:produto_id,d:quantidade,d:valor_liquido,d:status,d:satisfacao \
  gardenia:compras /gardenia/hbase/compras.tsv

hbase shell <<'SHELL'
count 'gardenia:compras'
# todas as compras do cliente 42 no lote 01, em ordem de data (scan por prefixo da chave)
scan 'gardenia:compras', {STARTROW => '01#0000042#', STOPROW => '01#0000042$'}
# uma compra específica
get 'gardenia:compras', '01#0000042#20260505185835#0000001'
SHELL
