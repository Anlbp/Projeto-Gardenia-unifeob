# Insights finais | Projeto Gardenia (lote 1)

Gerado em 13/11/2026. Dados de um simulador; veja as limitações.

## Números principais

| Indicador | Valor |
|---|---|
| Clientes cadastrados | 500 |
| Clientes que compraram | 247 |
| Compras no DW | 330 |
| Compras não canceladas | 243 |
| Receita líquida (não canceladas) | R$ 189.544,13 |
| Ticket médio (não canceladas) | R$ 780,02 |
| Taxa de cancelamento | 26,4% |

## Achados

### 1. Só uma parte dos registros chegou limpa

80,0% dos produtos e 66,0% das compras passaram para a zona trusted (330 de 500 compras). A regra que mais rejeita é 'preço <= 0 ou ausente' em produtos (100 ocorrências). Quando um produto vai para a quarentena, as compras dele vão junto, o que reduz o aproveitamento das compras.

**Recomendação:** Validar produto, preço e estoque na origem, antes de gravar o cadastro. Corrigir o produto devolve ao mesmo tempo as compras ligadas a ele.

**Confiança:** Alta (contagem direta dos registros)

### 2. Receita e cancelamento por categoria

Esportes lidera (R$ 92.013,50, 65,4% da receita) e Roupas fica por último; a distância é de 88,9%. Teste de Kruskal-Wallis no valor das compras: p = 0,270. Teste qui-quadrado no cancelamento por categoria: p = 0,073 (sem diferença significativa a 5%). 71 compras sem categoria informada (anulada na limpeza) ficam fora desta comparação.

**Recomendação:** Não priorizar uma categoria só por este resultado: a diferença de receita e de cancelamento entre elas é compatível com acaso. Decidir por margem, estoque e custo de aquisição, que não estão nos dados.

**Confiança:** Média: o teste não acusa diferença, mas só vale para o volume deste lote

### 3. Cancelamento atinge uma parte relevante dos pedidos

26,4% dos pedidos (87 de 330) foram cancelados. No simulador o pedido cancelado tem quantidade 0 e valor 0, então a perda em R$ não aparece nos dados: o que se mede é o número de pedidos. Por faixa etária a taxa vai de 14,3% (25-34) a 42,5% (45-54), mas essa diferença é significativa (p = 0,013). Outros 25,5% dos pedidos estão 'pendente' e entram na receita; se forem cancelados, a receita real cai.

**Recomendação:** Tratar o cancelamento como problema do processo de compra (pagamento, prazo, estoque), e não de um perfil de cliente ou categoria, a menos que o teste acima aponte diferença. Registrar o motivo e o valor do pedido cancelado na origem: hoje os dados só dizem que cancelou.

**Confiança:** Alta para a taxa de cancelamento; baixa para explicar a causa (não há motivo nem valor nos dados)

### 4. Receita mensal sem tendência clara

Considerando os meses completos (11), a receita média é R$ 15.205,53 por mês, com variação de 32,4% (desvio padrão sobre a média). Melhor mês: 2026-05 (R$ 23.665,24); pior: 2026-09 (R$ 7.641,56). Não há tendência significativa de crescimento ou queda (p = 0,940). O primeiro e o último mês (2025-11 e 2026-11) ficam de fora por estarem incompletos.

**Recomendação:** Planejar com a média mensal e a faixa de variação, sem assumir crescimento. Rodar mais lotes para separar sazonalidade de ruído.

**Confiança:** Média a baixa: poucos meses e dados simulados

### 5. Parte da base nunca comprou, e a recompra é limitada

Só 39,8% dos clientes cadastrados têm alguma compra não cancelada. Entre os que compraram, 79,9% compraram uma única vez. A faixa 25-34 gera a maior receita por cliente cadastrado (R$ 502,50) e responde por 21,2% da receita com 16,0% dos clientes.

**Recomendação:** Dois alvos: (1) ativar a base que nunca comprou, com uma primeira oferta; (2) levar quem comprou uma vez para a segunda compra, com cupom ou recomendação no prazo certo. Priorize o alvo com mais clientes nos números acima.

**Confiança:** Alta para os percentuais; média para a diferença entre faixas (não testada)

### 6. Segmentos de clientes: perfil do VIP e separação moderada entre grupos

O K-Means separou 3 grupos. O VIP tem 20,1% dos clientes e 34,1% do valor, com 2,10 compras em média contra 1,00 no grupo de menor frequência. A silhouette do modelo é 0,37 (moderada; o máximo testado, 0,46, foi com K = 2). Abaixo de 0,5, os grupos se tocam nas bordas. 79,9% dos clientes têm uma só compra, então a frequência também ajuda a separar os grupos.

**Recomendação:** Usar o VIP para fidelidade e acesso antecipado, e o grupo de menor engajamento para reativação com custo limitado. Tratar os rótulos como ponto de partida e conferir o perfil antes de uma campanha.

**Confiança:** Média: a separação entre grupos é moderada

## Limitações
- Os dados vêm de um simulador. Distribuições quase uniformes (categorias com receita parecida, cancelamento parecido em todos os grupos) são esperadas e não indicam comportamento de clientes reais.
- A limpeza descartou 34,0% das compras recebidas. Os resultados descrevem só as compras que passaram nas regras; se as rejeitadas tiverem perfil diferente, há viés.
- Cada ciclo do simulador reinicia os ids. Por isso os lotes foram tratados como bases separadas (chave lote + id) e não se pode acompanhar o mesmo cliente entre lotes.
- A receita inclui compras 'pendente' (25,5% do total). Só 'cancelado' foi excluído.
- Receita não é lucro: não há custo, margem nem frete nos dados. 79,9% dos clientes com compra têm uma só compra; quanto maior esse número, menos informação de frequência o RFM tem.
- Pedidos cancelados têm quantidade 0 e valor 0 no simulador: a taxa de cancelamento é em número de pedidos e a perda em R$ não é medida.
- Os testes estatísticos foram feitos sem correção para comparações múltiplas e sobre poucos meses; devem ser lidos como indício, não como prova.
- A silhouette (0,37) indica separação moderada entre os grupos. A segmentação ajuda a priorizar ações, mas não define fronteiras rígidas.

## Próximos passos
- Rodar mais lotes (e o consolidado no Spark) e conferir se os achados se repetem.
- Registrar o motivo e o valor do pedido cancelado, e a margem por produto, na origem, para recomendações financeiras.
- Validar produto e preço na origem para aproveitar mais compras na zona trusted.
- Testar uma ação de segunda compra e medir o efeito (grupo de teste e grupo de controle).
- Comparar o K-Means com outros algoritmos e outros conjuntos de variáveis (categoria preferida, desconto médio).
